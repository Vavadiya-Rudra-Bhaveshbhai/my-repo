
import yfinance as yf
import backtrader as bt
import pandas as pd
import matplotlib.pyplot as plt
import quantstats as qs
import os

def get_data(ticker):
    data = yf.download(ticker, start="2020-01-01", end="2023-12-31")
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.droplevel(1)
    if 'Adj Close' in data.columns:
        data.drop(columns=['Adj Close'], inplace=True)
    data['Volume'] = data['Volume'].fillna(0)
    return data

class TrendFollowingStrategy(bt.Strategy):
    params = dict(
        ema_fast=12,
        ema_slow=26,
        macd_signal=9,
        adx_period=14,
        adx_threshold=25,
    )

    def __init__(self):
        self.ema_fast = bt.ind.EMA(self.data.close, period=self.params.ema_fast)
        self.ema_slow = bt.ind.EMA(self.data.close, period=self.params.ema_slow)
        self.macd = bt.ind.MACD(self.data.close, period_me1=self.params.ema_fast,
                                period_me2=self.params.ema_slow, period_signal=self.params.macd_signal)
        self.adx = bt.ind.ADX(self.data, period=self.params.adx_period)

    def next(self):
        bullish = (self.ema_fast[0] > self.ema_slow[0] and
                   self.macd.macd[0] > self.macd.signal[0] and
                   self.adx[0] > self.params.adx_threshold)
        bearish = (self.ema_fast[0] < self.ema_slow[0] or
                   self.macd.macd[0] < self.macd.signal[0] or
                   self.adx[0] < self.params.adx_threshold)
        if not self.position and bullish:
            self.buy()
        elif self.position and bearish:
            self.close()

def run_backtest(df):
    cerebro = bt.Cerebro()
    cerebro.addstrategy(TrendFollowingStrategy)
    datafeed = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(datafeed)
    cerebro.broker.setcash(100000)
    cerebro.broker.setcommission(commission=0.001)

    print("Starting Portfolio Value: %.2f" % cerebro.broker.getvalue())
    cerebro.run()
    print("Final Portfolio Value: %.2f" % cerebro.broker.getvalue())

    output_dir = 'output'
    os.makedirs(output_dir, exist_ok=True)

    import matplotlib
    matplotlib.use('Agg')
    fig = cerebro.plot(style='candlestick', volume=False)[0][0]
    fig.savefig(f"{output_dir}/backtest_plot.png")

    returns = df['Close'].pct_change().dropna()
    qs.reports.html(returns, output=f"{output_dir}/performance_report.html")

if __name__ == "__main__":
    df = get_data('RELIANCE.NS')
    run_backtest(df)
